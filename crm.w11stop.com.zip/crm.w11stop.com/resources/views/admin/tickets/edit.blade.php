@extends('layouts.app')

@section('title', 'Edit Ticket')
@section('content')
<style>
 .select2-container--default .select2-results__option[aria-selected=true] {
    background-color: #ddd;
    pointer-events: none !important;
}
</style>

    <section class="section">
        <div class="section-body">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header d-flex align-items-center justify-content-between py-3">
                            <h4><i   data-feather="message-square" class="  h-i"></i> Ticket | Details</h4>
                            <a href="{{ route('tickets.index') }}" class="btn btn-primary">Back</a>
                        </div>
                        <div class="card-body">
                            @if ($errors->any())
                                <div class="alert alert-danger">
                                    <ul>
                                        @foreach ($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            @endif


                            <form action="{{ route('tickets.update', $ticket->id) }}" method="POST"
                                enctype="multipart/form-data">
                                @csrf
                                @method('PUT')
                                
                                <div class="detail-container">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <p class="d-p">Subject</p>
                                        </div>
                                        <div class="col-sm-6">
                                            <p class="d-p">{{ $ticket->subject }}</p>
                                        </div>
                                        <div class="line"></div>
                                    </div><!--row end-->
                                        {{-- ======== --}}
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <p class="d-p">Added By</p>
                                        </div>
                                        <div class="col-sm-6">
                                            <p class="d-p">{{ $ticket->user->name }}</p>
                                        </div>
                                        <div class="line"></div>
                                    </div><!--row end-->
                                        {{-- ======== --}}
                                    
                                    <div class="row">    
                                        <div class="col-sm-6">
                                            <p class="d-p">Ticket Status</p>
                                        </div>
                                        <div class="col-sm-6 ">
                                            <p class="d-p">

                                                @if($ticket->status == 'open' )
                                                <button class="btn btn-success" >Open</button>
                                                @elseif($ticket->status == 'in-progress' )
                                                <button class="btn btn-primary" >In Progress</button>
                                                @else
                                                <button class="btn btn-danger" >Close</button>
                                                @endif
                                            </p>
                                        </div>
                                        <div class="line"></div>
                                    </div><!--row end-->
                                    {{-- ======== --}}

                                    <div class="row">
                                        <div class="col-sm-6">
                                            <p class="d-p">Concerned Department</p>
                                        </div>
                                        <div class="col-sm-6">
                                            <p class="d-p">
                                                @foreach ($departments as $department)
                                            
                                                    @if (in_array($department->id, $ticket->departments->pluck('id')->toArray())) 
                                                    {{ $department->name }}
                                                    @endif
                                                
                                                @endforeach
                                            </p>
                                        </div>
                                        <div class="line"></div>
                                    </div><!--row end-->
                                    {{-- ======== --}}

                                    <div class="row">
                                        <div class="col-sm-6">
                                            <p class="d-p">CC To</p>
                                        </div>
                                        <div class="col-sm-6">
                                            {{-- <p class="d-p">
                                                @foreach ($employees as $employee)
                                                    @if(in_array($employee->id, $ticket->employees->pluck('id')->toArray()))
                                                    {{ $employee->name }}                                                
                                                    @endif
                                        
                                                @endforeach
                                            </p> --}}
                                            
                                        <!-- Multiple Employee Selection -->
                                        @if (in_array('employee_id', $fields))
                                        <div class="form-group emp_select_2">
                                            
                                            <select id="employee_id" name="employee_ids[]" class="form-control  select2"
                                                multiple>
                                                @foreach ($employees as $employee)
                                                    <option value="{{ $employee->id }}"
                                                        {{ in_array($employee->id, $ticket->employees->pluck('id')->toArray()) ? 'selected' : '' }}>
                                                        {{ $employee->name }}
                                                    </option>
                                                @endforeach
                                            </select>
                                        </div>
                                    @endif
                                        </div>
                                        <div class="line"></div>
                                    </div><!--row end-->
                                    {{-- ======== --}}
                                </div>

                                @php
                                    // dd([
                                    //     'hasSalesRole' => $user->hasRole('Sales'),
                                    //     'hasManagerRole' => $user->hasRole('manager'),
                                    // ]);
                                @endphp
                                <!-- Display fields based on department and user role -->
                                <div class="row">

                                    @if (
                                        $user->hasRole(['Manager', 'Super Admin']) ||
                                            ($user->department && $user->department->name === 'Sales' && $ticket->created_by == $user->id))
                                        <div class="form-group col-md-6">
                                            <label>Price</label>
                                            <input type="text" name="price" class="form-control"
                                                value="{{ $ticket->price }}" disabled>
                                        </div>
                                    @endif

                                
                                    <!-- Description -->
                                    {{-- <div class="form-group">
                                        <label>Message</label>
                                        <textarea id="description" class="form-control" rows="5" readonly>{!! $ticket->description !!}</textarea>
                                    </div> --}}

                                    @if (
                                        ($user->department && $user->hasRole('Sales')) ||
                                            ($user->hasRole('manager') && $ticket->user_id == Auth::user()->id))
                                        <!-- Client Details -->
                                        <div class="form-group  col-md-6">
                                            <label>Client Name</label>
                                            <input type="text" id="c_name" name="c_name" class="form-control"
                                                value="{{ $ticket->client->name }}" disabled>
                                        </div>
    
                                    @endif


                                    <!-- Check if Project Name is not null or empty -->
                                    @if (!empty($ticket->project_name))
                                        <div class="form-group  col-md-6">
                                            <label>Project Name</label>
                                            <input type="text" name="project_name" class="form-control"
                                                value="{{ old('project_name', $ticket->project_name) }}" required>
                                        </div>
                                    @endif

                                    <!-- Check if Project Deadline is not null or empty -->
                                    @if (!empty($ticket->project_deadline))
                                        <div class="form-group  col-md-6">
                                            <label>Project Deadline</label>
                                            <input type="date" name="project_deadline" class="form-control"
                                                value="{{ old('project_deadline', $ticket->project_deadline) }}" required>
                                        </div>
                                    @endif

                                    <!-- Departments -->
                                    {{-- <div class="form-group col-md-4">
                                        <label>Departments</label>
                                        <select id="department_id" name="department_ids[]" class="form-control">
                                            @foreach ($departments as $department)
                                                <option value="{{ $department->id }}"
                                                    @if (in_array($department->id, $ticket->departments->pluck('id')->toArray())) selected @endif>
                                                    {{ $department->name }}
                                                </option>
                                            @endforeach
                                        </select>
                                    </div> --}}



                                    <!-- Sub Departments -->
                                    {{-- <div class="form-group col-md-4" >
                                        <label>Sub Departments</label>
                                        <select id="sub_department_id" name="sub_department_ids[]" class="form-control "
                                            >
                                            @foreach ($subDepartments as $subDepartment)
                                                <option value="{{ $subDepartment->id }}"
                                                    @if (in_array($subDepartment->id, $ticket->subDepartments->pluck('id')->toArray())) selected @endif>
                                                    {{ $subDepartment->name }}
                                                </option>
                                            @endforeach
                                        </select>
                                    </div> --}}

                                  
                                                                    


                                    {{-- <div class="card mb-4 col-md-12">
                                        <div class="card-header">   
                                            <h5>Comments</h5>
                                        </div>
                                        <div class="card-body">
                                            @foreach($ticket->comments as $comment)
                                            <div class="comment mb-4 p-3 border rounded">
                                                <div class="d-flex justify-content-between align-items-center mb-2">
                                                    <h5 class="mb-0">Comment by {{ $comment->user->name }}</h5>
                                                    <small class="text-muted">{{ $comment->created_at->format('d M Y, h:i A') }}</small>
                                                </div>
                                                <div id="comment_{{ $comment->id }}" class="comment-content p-2 border rounded bg-light" style="max-height: 150px; overflow-y: auto;">
                                                    {!! $comment->comment !!}
                                                </div>
                                        
                                                <!-- Attachments for this comment -->
                                                @if($comment->attachments->count())
                                                    <div class="mt-2">
                                                        <label>Attachments:</label>
                                                        <div class="attachment-list">
                                                            @foreach($comment->attachments as $attachment)
                                                                <div class="attachment-item">
                                                                    <a href="{{ route('attachments.comment.download', $attachment->id) }}" class="btn btn-secondary btn-sm" target="_blank">
                                                                        {{ $attachment->file_name }}
                                                                    </a>
                                                                </div>
                                                            @endforeach
                                                        </div>
                                                    </div>
                                                @endif
                                            </div>
                                        @endforeach
                                        
                                        


                                        </div>
                                    </div> --}}


                                    {{-- //chat ui  --}}
                                    <div class="col-12">
                                        <div class="chat-box">

                                            @foreach($ticket->comments as $comment)
                                            
                                         
                                                <!--// User Message-->

                                                @if($comment->comment != 'Attachment uploaded without a comment')
                                                <div class="flex-client">
                                                        <div class="client-messgae">
                                                            <div class="flex-name-client">
                                                                <p class="p_name">
                                                                    {{ $comment->user->name }}
                                                                </p>
                                                            </div>

                                                            <div class="message-p">{!! $comment->comment !!}</div>
                                                            
                                                            <!--// User Message Attachment-->
                                                            @if($comment->attachments->count())
                                                                @foreach($comment->attachments as $attachment)
                                                                    <div class="attachment-item">
                                                                        <a href="{{ route('attachments.comment.download', $attachment->id) }}" class="attachment_self" target="_blank">
                                                                            <i data-feather="download" class="h-i"></i>
                                                                            {{ Str::limit($attachment->file_name, 20) }}
                                                                            
                                                                        </a>
                                                                    </div>
                                                                @endforeach
                                                            @endif

                                                            <div class="flex-date">
                                                                <p class="p_date">
                                                                    {{ $comment->created_at->format('d M Y, h:i A') }}
                                                                </p>
                                                            </div>
                                                        </div>
                                                </div>
                                                @endif
                                                

                                                
                                            @endforeach


                                        </div><!--chat-box end-->
                                    </div>


                                    <!-- Comments -->
                                    <div class="form-group col-md-12">
                                        <label>Add Message</label>
                                        <textarea id="comment" name="comment" class="form-control">{{ old('comment') }}</textarea>
                                    </div>


                                    <!-- Attachments -->
                                    <div class="form-group col-sm-6 ">
                                        <label>Attachments </label>
                                        <div class="attachment-list">
                                            @if ($ticket->attachments->count())
                                                <a href="{{ route('attachments.downloadAll', $ticket->id) }}"
                                                    class="attachment_self my-1">
                                                    <i data-feather="download" class="h-i"></i>
                                                    Download All Attachments
                                                </a>
                                            @endif
                                            @foreach ($ticket->attachments as $attachment)
                                                <div class="attachment-item mb-2">
                                                    <a href="{{ route('attachments.download', $attachment->id) }}"
                                                        class="attachment_self my-1" target="_blank">
                                                        <i data-feather="download" class="h-i"></i>
                                                        {{ $attachment->file_name }}
                                                    </a>
                                                </div>
                                            @endforeach
                                        </div>
                                        
                                        <input type="file" name="comment_attachments[]" class="form-control" multiple>
                                    </div>


                                    <!-- Priority -->
                                    <div class="form-group col-md-3">
                                        <label>Priority</label>
                                        <select name="priority" class="form-control" >
                                            <option value="low" {{ $ticket->priority == 'low' ? 'selected' : '' }}>Low
                                            </option>
                                            <option value="medium" {{ $ticket->priority == 'medium' ? 'selected' : '' }}>Medium
                                            </option>
                                            <option value="high" {{ $ticket->priority == 'high' ? 'selected' : '' }}>High
                                            </option>
                                        </select>
                                    </div>
                                    
                                    <!-- Status -->
                                    <div class="form-group col-sm-3 ">
                                        <label>Status</label>
                                            <select name="status" class="form-control">
                                                <option value="open" {{ $ticket->status == 'open' ? 'selected' : '' }}>Open
                                                </option>
                                                <option value="in-progress"
                                                    {{ $ticket->status == 'in-progress' ? 'selected' : '' }}>In Progress</option>
                                                <option value="closed" {{ $ticket->status == 'closed' ? 'selected' : '' }}>Closed
                                                </option>
                                            </select>
                                        </div>


                                    <div class="col-md-12  ">
                                         
                                            <div>
                                                <button type="submit" class="btn btn-primary">Update Ticket</button>
                                            </div>
                                         
                                    </div>
                                </div><!--row end-->
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection

@section('customJs')
    <script>
        $(document).ready(function() {
            $('#clients').select2({
                placeholder: "Select clients", // Placeholder text
                allowClear: true // Option to clear the selection
            });
            // $('#department_id').select2({
            //     placeholder: "Select departments", // Placeholder text
            //     allowClear: true // Option to clear the selection
            // });
            // $('#sub_department_id').select2({
            //     placeholder: "Select Sub departments", // Placeholder text
            //     allowClear: true // Option to clear the selection
            // });
            $('#employee_id').select2({
                placeholder: "Select CC",
                allowClear: false,
                closeOnSelect: true
            })
        });
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize TinyMCE for displaying existing comments in read-only mode
            tinymce.init({
                selector: '#description',
                menubar: false, // Hide menubar
                toolbar: false, // Hide toolbar
                readonly: true, // Make it read-only
                setup: function(editor) {
                    editor.on('init', function() {
                        editor.getBody().setAttribute('contenteditable',
                            false); // Ensure it's not editable
                    });
                }
            });

            // Initialize TinyMCE for the new comment field (editable)
            tinymce.init({
                selector: '#comment',
            });
        });
    </script>
@endsection
