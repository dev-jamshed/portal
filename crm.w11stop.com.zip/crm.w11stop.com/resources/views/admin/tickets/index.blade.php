@extends('layouts.app')

@section('title', 'Tickets')


@section('content')
    <section class="section">
        <div class="card">
            <div class="card-header">
                <h4><i   data-feather="message-square" class="  h-i"></i> Manage Tickets</h4>
                <a class="btn btn-primary" href="{{ route('tickets.create') }}">New Tickets</a>
            </div>
        </div>
    </section>
  
    <section class="section">
        <div class="card">
            <div class="card-body">
                <form  action="#"    >
                    <div class="row filter-container">

                        <div class="form-group col-md-2">
                            <label>Search</label>
                            <select name="user_id" class="form-control"                        >
                                <option selected disabled >User ID</option>
                        
                                @foreach ($users as $userData)
                                    <option value="{{ $userData->id }}">
                                        {{ $userData->id }}
                                    </option>
                                @endforeach
                            </select>
                        </div>

                    
                        
                        <div class="form-group col-md-4">
                            <label>Subject</label>
                            <input type="text" name="subject" placeholder="Subject" class="form-control" value="{{ old('subject') }}"
                            required>
                        </div>
                        
                        <div class="form-group col-md-4">
                            <label>Department</label>
                            <select name="department" class="form-control">
                                <option selected disabled >Please Select Department</option>
                        
                                @foreach ($Departments as $Department)
                                    <option value="{{ $Department->id }}">
                                        {{ $Department->name }}
                                    </option>
                                @endforeach
                            </select>
                        </div>

                    
                        <div class="form-group col-md-2">
                            <label>Ticket Status</label>
                            <select name="department" class="form-control" >
                                <option selected disabled >Select</option>
                                    <option value="open">
                                        Open
                                    </option>
                                    <option value="in-progress">
                                        In Progress
                                    </option>
                                    <option value="closed">
                                        Closed
                                    </option>
                            </select>
                        </div>

                        <div class="form-group col-md-3">
                            <label>Ticket ID</label>
                            <input type="text" name="ticket_id" placeholder="Ticket ID" class="form-control" value="{{ old('ticket_id') }}"
                            required>
                        </div>
                    
                        <div class="form-group col-md-4">
                            <label>Added By</label>

                            <select name="ticket_id" class="form-control"                        >
                            <option selected disabled >Select </option>
                                @foreach ($users as $userData)
                                    <option value="{{ $userData->id }}">
                                        {{ $userData->name }}
                                    </option>
                                @endforeach
                            </select>
                        </div>

                        <div class="col-md-3">
                            <div class="flex-button-2">
                                <div>
                                    <button type="submit" class="btn btn-primary">Search</button>
                                </div>
                            </div>
                        </div>
                        
                    </div><!--row end -->
                </form>
            </div>  
        </div>
    </section>

    <section class="section">
        <div class="section-body">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped" id="table-1">
                                    <thead>
                                        <tr>
                                            <th class="text-center">S#</th>
                                            <th class="text-center">Department</th>
                                            <th class="text-center">Subject</th>
                                            <th class="text-center">Priority</th>
                                            <th class="text-center">Added By</th>
                                            <th class="text-center">Status</th>
                                            <th class="text-center">Created At</th>
                                            <th class="text-center">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($tickets as $ticket)
                                            <tr>
                                                <td class="text-center">{{ $ticket->id }}</td>
                                                <td class="text-center">
                                                    @if($ticket->departments->isNotEmpty())
                                                        {{ $ticket->departments->pluck('name')->implode(', ') }}
                                                    @else
                                                        N/A
                                                    @endif
                                                </td>
                                                
                                                <td class="text-center">{{ $ticket->subject }}</td>


                                                <td class="text-center">
                                                    
                                                    <span class="badge badge-shadow 
                                                    @if($ticket->priority  == 'High')
                                                     badge-danger 
                                                    @elseif($ticket->priority  == 'Medium')
                                                        badge-primary
                                                    @else
                                                        badge-success
                                                    @endif
                                                    ">
                                                        
                                                        {{ $ticket->priority }}
                                                    </span>
                                                
                                                
                                                </td>

                                                <td class="text-center">{{ $ticket->user->name }}</td>
                                                
                                                <td class="text-center">
                                                    
                                                    <span class="badge badge-shadow 
                                                        @if($ticket->status == 'open' )
                                                        badge-success  
                                                        @elseif($ticket->status == 'in-progress' )
                                                        badge-primary  
                                                        @else
                                                        badge-danger 
                                                        @endif
                                                    ">
                                                        {{ $ticket->status}}
                                                    </span>
                                                </td>
                                               
                                                <td class="text-center">{{ $ticket->created_at->format('d M Y') }}</td>
                                                <td class="just-flex">
                                                    <form class="my-0-mx-auto"
                                                        action="{{ route('tickets.destroy', $ticket->id) }}"
                                                        method="post">
                                                        @csrf
                                                        @method('DELETE')
                                                        <table>
                                                            <tr>
                                                                <td>
                                                                    <a href="{{ route('tickets.edit', $ticket->id) }}"
                                                                        class="btn btn-primary btn-md">
                                                                        <i class="fa-regular fa-eye h-i-2"></i>
                                                                    </a>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </form>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
