<?php $__env->startSection('title', 'Manage Users'); ?>

<?php $__env->startSection('content'); ?>


    <section class="section">
        <div class="section-body">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped" id="table-1">
                                    <thead>
                                        <tr>
                                            <th class="text-center">S#</th>
                                            <th class="text-center">Date</th>
                                            <th class="text-center">Name</th>
                                            <th class="text-center">In Time</th>
                                            <th class="text-center">Out Time</th>
                                            <th class="text-center">Work Time</th>
                                            <th class="text-center">Attendance Status</th>
                                            <th class="text-center">User IP</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="text-center"><?php echo e($attendance->id); ?></td>
                                            <td class="text-center"><?php echo e(\Carbon\Carbon::parse($attendance->date)->format('d-M-Y')); ?></td>
                                            <td class="text-center">  <?php echo e($attendance->user ? $attendance->user->name : 'N/A'); ?></td>
                                            <?php if($attendance->attendance_status == 'absent'): ?>
                                                <td class="text-center" style="color: red;">Absent</td>
                                                <td class="text-center" style="color: red;">Absent</td>
                                                <td class="text-center" style="color: red;">Absent</td>
                                                <td class="text-center" style="color: red;">Absent</td>
                                            <?php elseif($attendance->attendance_status == 'holiday'): ?>
                                                <td class="text-center" style="color: green;">Holiday</td>
                                                <td class="text-center" style="color: green;">Holiday</td>
                                                <td class="text-center" style="color: green;">Holiday</td>
                                                <td class="text-center" style="color: green;">Holiday</td>
                                            <?php else: ?>
                                                <td class="text-center" style="color: <?php echo e($attendance->check_in_status == 'late' ? 'red' : 'green'); ?>">
                                                    <?php echo e($attendance->in_time); ?> (<?php echo e($attendance->check_in_status); ?>)
                                                </td>
                                                <td class="text-center" style="color: <?php echo e($attendance->check_out_status == 'late' ? 'red' : 'green'); ?>">
                                                    <?php echo e($attendance->out_time); ?> (<?php echo e($attendance->check_out_status); ?>)
                                                </td>
                                                <td class="text-center"><?php echo e($attendance->total_work_time); ?></td>
                                                <td class="text-center" style="color: green;"><?php echo e(ucfirst($attendance->attendance_status)); ?></td>
                                            <?php endif; ?>
                                            <td class="text-center"><?php echo e($attendance->user_ip); ?></td>
                                            
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO T430\Desktop\crm.w11stop.com\resources\views/admin/attendance/index.blade.php ENDPATH**/ ?>