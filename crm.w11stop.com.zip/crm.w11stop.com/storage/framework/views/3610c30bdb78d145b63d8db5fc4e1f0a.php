<!DOCTYPE html>
<html lang="en">
<!-- basic-form.html  21 Nov 2019 03:54:41 GMT -->

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('frontend')); ?>/images/logo.png">
    <meta name="robots" content="no-index, no-follow">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- General CSS Files -->
    <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/assets/css/app.min.css">
    <!-- Template CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.css" />
    <!-- include summernote js-->
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.js"></script>

    <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/assets/bundles/datatables/datatables.min.css">
    <link rel="stylesheet"
        href="<?php echo e(asset('admin')); ?>/assets/bundles/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css">

    <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/assets/css/style.css">
    <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/assets/css/components.css">
    <!-- Custom style CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/assets/css/custom.css">
    <link rel='shortcut icon' type='image/x-icon' href='<?php echo e(asset('admin')); ?>/assets/img/w11-stop-logo.png' />
    <link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.6.0/css/all.css">


    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/select2/css/select2.min.css')); ?>">
    <!-- Add these to your <head> section -->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.2/dist/css/select2.min.css" rel="stylesheet" />



</head>
<?php
    use Illuminate\Support\Str;
?>

<?php
    use App\Helpers\AttendanceHelper;

    $attendance = AttendanceHelper::getTodayAttendanceForUser(Auth::user()->id);

    // dd($attendance)

?>

<body>

    
    <div id="app">
        <div class="main-wrapper main-wrapper-1">
            <div class="navbar-bg"></div>
            <nav class="navbar navbar-expand-lg main-navbar sticky">
                <div class="form-inline mr-auto">
                    <ul class="navbar-nav mr-3">
                        <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg
									collapse-btn">
                                <i data-feather="align-justify"></i></a></li>
                        <li><a href="#" class="nav-link nav-link-lg fullscreen-btn">
                                <i data-feather="maximize"></i>
                            </a></li>
                        
                    </ul>
                </div>
                <ul class="navbar-nav navbar-right">

                    <?php if(isset(Auth::user()->name)): ?>
                        <li class="dropdown"><a href="#" data-toggle="dropdown"
                                class="nav-link dropdown-toggle nav-link-lg nav-link-user"> <span
                                    class='auth-name'><?php echo e(isset(Auth::user()->name) ? Auth::user()->name : ''); ?></span>
                                <img alt="image" src="<?php echo e(asset('admin')); ?>/assets/img/user-placeholder.png"
                                    class="user-img-radious-style"> <span
                                    class="d-sm-none d-lg-inline-block"></span></a>
                            <div class="dropdown-menu dropdown-menu-right pullDown">

                                <div class="dropdown-title"><?php echo e(isset(Auth::user()->name) ? Auth::user()->name : ''); ?>

                                </div>
                                
                                <!-- </a> <a href="timeline.html" class="dropdown-item has-icon"> <i class="fas fa-bolt"></i>-->
                                <!--  Activities-->
                                <!--</a>-->
                                <a href="<?php echo e(route('profile.edit')); ?>" class="dropdown-item has-icon"> <i
                                        class="fas fa-cog"></i>
                                    Profile Settings
                                </a>



                                <?php if(
                                    $attendance &&
                                        in_array($attendance->attendance_status, ['present', 'late', 'half_day']) &&
                                        is_null($attendance->out_time)): ?>
                                    <a href="<?php echo e(route('attendance.checkout')); ?>"
                                        onclick="event.preventDefault(); document.getElementById('checkout-form').submit();"
                                        class="dropdown-item has-icon">
                                        <i class="fas fa-sign-out-alt"></i> Check-out
                                    </a>
                                    <form id="checkout-form" action="<?php echo e(route('attendance.checkout')); ?>" method="POST"
                                        class="d-none">
                                        <?php echo csrf_field(); ?>
                                        <input hidden type="text" name="employee_id" value="<?php echo e(Auth::user()->id); ?>"
                                            required readonly>
                                    </form>
                                <?php endif; ?>

                                <div class="dropdown-divider"></div>
                                <a href="<?php echo e(route('logout')); ?>"
                                    onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();"
                                    class="dropdown-item has-icon text-danger"> <i class="fas fa-sign-out-alt"></i>
                                    Logout
                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>

                            </div>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
            <div class="main-sidebar sidebar-style-2">
                <aside id="sidebar-wrapper">
                    <div class="sidebar-brand">
                        <a href="<?php echo e(url('/')); ?>"> <img class="logo-w11"
                                src="<?php echo e(asset('admin')); ?>/assets/img/w11-stop-logo.png" alt="">
                            
                        </a>
                    </div>
                    <ul class="sidebar-menu">

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view dashboard'])): ?>
                        <li class="dropdown <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('dashboard')); ?>" class="nav-link"><i
                                    data-feather="monitor"></i><span>Dashboard</span></a>
                        </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage tickets'])): ?>
                            <li
                                class="dropdown  <?php echo e(request()->routeIs('tickets.index', 'tickets.create', 'tickets.edit') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('tickets.index')); ?>" class="nav-link"><i
                                        data-feather="message-square"></i><span>Tickets</span></a>
                            </li>
                        <?php endif; ?>



                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['create-role', 'edit-role', 'delete-role'])): ?>
                            <li
                                class="dropdown <?php echo e(request()->routeIs('roles.index', 'roles.edit', 'roles.create', 'roles.show') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('roles.index')); ?>" class="nav-link"><i
                                        data-feather="settings"></i><span>Manage Roles</span></a>
                            </li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['create-user', 'edit-user', 'delete-user'])): ?>
                            <li
                                class="dropdown <?php echo e(request()->routeIs('users.index', 'users.show', 'users.edit', 'users.create') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('users.index')); ?>" class="nav-link "><i
                                        data-feather="users"></i><span>Manage Users</span></a>
                            </li>
                        <?php endif; ?>



                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['create deparment', 'update deparment', 'delete deparment'])): ?>
                            <li
                                class="dropdown <?php echo e(request()->routeIs('departments.index', 'departments.edit', 'departments.create', 'departments.show') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('departments.index')); ?>" class="nav-link"><i
                                        data-feather="package"></i><span>Manage Departments</span></a>
                            </li>
                        <?php endif; ?>


                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view subdepartment', 'update subdepartment', 'delete subdepartment'])): ?>
                            <li
                                class="dropdown <?php echo e(request()->routeIs('subDepartments.index', 'subDepartments.show', 'subDepartments.edit', 'subDepartments.create') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('subDepartments.index')); ?>" class="nav-link "><i
                                        data-feather="users"></i><span>Manage Sub Departments</span></a>
                            </li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any([
                            'create workFromHomePermission',
                            'update workFromHomePermission',
                            'view
                            workFromHomePermission',
                            ])): ?>
                            <li
                                class="dropdown <?php echo e(request()->routeIs('work_from_home.index', 'work_from_home.edit') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('work_from_home.index')); ?>" class="nav-link "><i
                                        data-feather="clock"></i><span>Work From Home</span></a>
                            </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage-schedules'])): ?>
                            <li
                                class="dropdown <?php echo e(request()->routeIs('schedules.index', 'schedules.edit') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('schedules.index')); ?>" class="nav-link "><i
                                        data-feather="calendar"></i><span>Schedules</span></a>
                            </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view attendance'])): ?>
                            <li class="dropdown <?php echo e(request()->routeIs('attendance.index') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('attendance.index')); ?>" class="nav-link "><i
                                        data-feather="check"></i><span>Attendances</span></a>
                            </li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage-logo-recruitment'])): ?>
                            <li class="dropdown <?php echo e(request()->routeIs('logoRecruitment.index','logoRecruitment.edit') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('logoRecruitment.index')); ?>" class="nav-link "><i
                                        data-feather="figma"></i><span>Logo Recruitment</span></a>
                            </li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage-web-recruitment'])): ?>
                            <li class="dropdown <?php echo e(request()->routeIs('website_requirements.index','website_requirements.edit') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('website_requirements.index')); ?>" class="nav-link "><i
                                        data-feather="clipboard"></i><span>Web Recruitment</span></a>
                            </li>
                        <?php endif; ?>





                        




                    </ul>
                </aside>
            </div>

            <!-- Main Content -->
            <div class="main-content">
                <?php echo $__env->yieldContent('content'); ?>
                
            </div>

            <footer class="main-footer">
                <div class="footer-left">
                    <!--<a href="https://w11stop.com/" target='_blank'>W11Stop -  One Stop, All Solutions </a></a>-->
                    <a href="https://w11stop.com/" target="_blank">W11Stop - One Stop, All Solutions</a>
                    <br>

                    <span style="font-size: 10px;">Powered by <a href="https://www.diginotive.com"
                            target="_blank">Diginotive.com</a></span>

                </div>
                <div class="footer-right">
                </div>
            </footer>


        </div>
    </div>
    <!-- General JS Scripts -->
    <script src="<?php echo e(asset('admin')); ?>/assets/js/app.min.js"></script>
    <!-- JS Libraies -->

    <script src="<?php echo e(asset('admin')); ?>/assets/bundles/datatables/datatables.min.js"></script>
    <script src="<?php echo e(asset('admin')); ?>/assets/bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js">
    </script>
    <!-- Page Specific JS File -->
    <!-- Template JS File -->
    <script src="<?php echo e(asset('admin')); ?>/assets/bundles/jquery-ui/jquery-ui.min.js"></script>

    <script src="<?php echo e(asset('admin')); ?>/assets/js/page/datatables.js"></script>
    <script src="<?php echo e(asset('admin')); ?>/assets/js/scripts.js"></script>


    <script src="<?php echo e(asset('admin/assets/bundles/summernote/summernote-bs4.js')); ?>"></script>
    <!-- Custom JS File -->
    <script src="<?php echo e(asset('admin')); ?>/assets/js/custom.js"></script>

    <script src="<?php echo e(asset('admin/assets/select2/js/select2.min.js')); ?>"></script>

    <!-- Add these to your <head> section -->
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.2/dist/js/select2.min.js"></script>
    <script src="https://cdn.ckeditor.com/ckeditor5/ckeditor.js"></script>
    <script src="https://cdn.tiny.cloud/1/ip4tafkbma1r2wdwp7slxc7f75lhvuckfqlb1dnwkdl7b4ww/tinymce/6/tinymce.min.js">
    </script>



    <?php echo $__env->yieldContent('customJs'); ?>
</body>


<!-- basic-form.html  21 Nov 2019 03:54:41 GMT -->

</html>



<?php if(Auth::check()): ?>

    <?php if($attendance): ?>
    

        
        <?php if($attendance->uid === Auth::user()->id): ?>
            
            <?php if($attendance->attendance_status === 'absent'): ?>
                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire({
                            title: 'Check-in Required',
                            text: 'Please check-in before proceeding!',
                            icon: 'warning',
                            allowOutsideClick: false,
                            allowEscapeKey: false,
                            showCancelButton: false,
                            confirmButtonText: 'Check-in'
                        }).then((result) => {
                            if (result.isConfirmed) {
                                document.getElementById('checkinForm').submit();
                            }
                        });
                    });
                </script>

                
            
            <?php else: ?>
                
            <?php endif; ?>
        <?php else: ?>
            
        <?php endif; ?>
    <?php else: ?>
       <?php if($attendance === null): ?>
      
       <script>
        document.addEventListener('DOMContentLoaded', function() {
            Swal.fire({
                title: 'Check-in Required',
                text: 'Please check-in before proceeding!',
                icon: 'warning',
                allowOutsideClick: false,
                allowEscapeKey: false,
                showCancelButton: false,
                confirmButtonText: 'Check-in'
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById('checkinForm').submit();
                }
            });
        });
    </script>

    <form id="checkinForm" action="<?php echo e(route('attendance.checkin')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input hidden type="text" id="checkin_employee_id" name="employee_id"
            value="<?php echo e(Auth::user()->id); ?>" required readonly>
        <button type="submit" class="btn btn-primary">Check-in</button>
    </form>
       <?php endif; ?>
    <?php endif; ?>
<?php else: ?>
    
<?php endif; ?>


<!-- SweetAlert JS -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.0/dist/sweetalert2.all.min.js"></script>
<?php /**PATH C:\Users\Farhan ALi\Downloads\new portal\crm.w11stop.com\resources\views/layouts/app.blade.php ENDPATH**/ ?>