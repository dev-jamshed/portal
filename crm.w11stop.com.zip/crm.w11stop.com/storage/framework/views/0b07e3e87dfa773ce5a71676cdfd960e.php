 
<?php $__env->startSection('title',' Add New Ddepartments'); ?>

<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="section-body">
      <div class="row">


        <div class="col-12">
          <div class="card">
            <div class="card-header d-flex align-items-center justify-content-between py-3 ">
              <h4><i  data-feather="package" class=" h-i" ></i>  Add New Departments</h4>
              <a href="<?php echo e(route('departments.index')); ?>" class="btn btn-primary">Back</a>
            </div>
          </div>
        </div>


        <div class="col-md-12">
          <div class="card">

            <div class="card-body">
                <form  action="<?php echo e(route('departments.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="row">


                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Name</label>
                                <input type="text"  class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required
                                id="name" name="name" value="<?php echo e(old('name')); ?>" >
                                <?php if($errors->has('name')): ?>
                                <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                <?php endif; ?>
                            </div>
                                
                        </div>





                    </div>
                    <div class="card-footer text-left">
                        <button id="btn" class="btn btn-primary " type="submit">Add Department</button>
                    </div>
                </form>

          </div>
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Farhan ALi\Downloads\new portal\crm.w11stop.com\resources\views/admin/departments/create.blade.php ENDPATH**/ ?>