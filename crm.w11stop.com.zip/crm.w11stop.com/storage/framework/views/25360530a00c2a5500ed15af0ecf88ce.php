<?php $__env->startSection('title', 'Manage Departments'); ?>

<?php $__env->startSection('content'); ?>


    <section class="section">
        <div class="card">
            <div class="card-header">
                <h4><i class="fa-solid fa-clipboard-question h-i" ></i> Manage Departments</h4>
                <a class="btn btn-primary" href="<?php echo e(route('departments.create')); ?>"> <i class="fa-solid fa-plus h-i-2"></i>Add New Departments</a>
            </div>
        </div>
    </section>


    <section class="section">
        <div class="section-body">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped" id="table-1">
                                    <thead>
                                        <tr>
                                            <th class="text-center">
                                                S#
                                            </th>
                                            <th class="text-center">Name</th>

                                            <th class="text-center">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="text-center"><?php echo e($department->id); ?></td>
                                            <td class="text-center"><?php echo e($department->name); ?></td>
                                            <td class="just-flex">

                                                <form class="my-0-mx-auto" action="<?php echo e(route('departments.destroy', $department->id)); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>

                                                    <table>
                                                        <tr>

                                                       
                                                  
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update deparment')): ?>
                                                        <td>

                                                            <a href="<?php echo e(route('departments.edit', $department->id)); ?>" class="btn btn-primary btn-sm"><i class="fa-regular fa-pen-to-square"></i></a>
                                                        </td>
                                                        <?php endif; ?>

                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete deparment')): ?>
                                                          
                                                            <td>
                                                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Do you want to delete this Departments?');"><i class="fa-regular fa-trash"></i></button>
                                                            </td>
                                                          
                                                        <?php endif; ?> 
                                                  
                                                        </tr>
                                                    </table>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO T430\Desktop\crm.w11stop.com\resources\views/admin/departments/index.blade.php ENDPATH**/ ?>