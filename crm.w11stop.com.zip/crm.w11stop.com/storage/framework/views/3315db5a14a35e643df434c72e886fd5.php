<?php $__env->startSection('title', 'Edit User'); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-body">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header d-flex align-items-center justify-content-between py-3">
                            <h4><i class="fa-regular fa-user h-i"></i> Edit User</h4>
                            <a href="<?php echo e(route('users.index')); ?>" class="btn btn-primary">Back</a>
                        </div>
                    </div>
                </div>

                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <form action="<?php echo e(route('users.update', $user->id)); ?>" method="post"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="row">
                                    <!-- Name Field -->
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Name</label>
                                            <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                required id="name" name="name"
                                                value="<?php echo e(old('name', $user->name)); ?>">
                                            <?php if($errors->has('name')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <!-- Email Field -->
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Email Address</label>
                                            <input type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                required id="email" name="email"
                                                value="<?php echo e(old('email', $user->email)); ?>">
                                            <?php if($errors->has('email')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <!-- Profile Picture Field -->
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Profile Picture</label>
                                            <input type="file"
                                                class="form-control <?php $__errorArgs = ['picture'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="picture"
                                                name="picture">
                                            <?php if($errors->has('picture')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('picture')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <!-- Phone Number Field -->
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Phone Number</label>
                                            <input type="text" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                required id="phone" name="phone"
                                                value="<?php echo e(old('phone', $user->phone)); ?>">
                                            <?php if($errors->has('phone')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <!-- Password Field -->
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Password</label>
                                            <input type="password"
                                                class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password"
                                                name="password">
                                            <?php if($errors->has('password')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <!-- Confirm Password Field -->
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Confirm Password</label>
                                            <input type="password"
                                                class="form-control <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="password_confirmation" name="password_confirmation">
                                            <?php if($errors->has('password_confirmation')): ?>
                                                <span
                                                    class="text-danger"><?php echo e($errors->first('password_confirmation')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <!-- Department Dropdown -->
                                    <div class="col-md-6" id="department-dropdown"
                                        style="<?php echo e($user->roles->contains('Employee') ? 'display: block;' : 'display: none;'); ?>">
                                        <div class="form-group">
                                            <label>Department</label>
                                            <select class="form-control" name="department_id">
                                                <option value="">Select a Department</option>
                                                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($department->id); ?>"
                                                        <?php echo e(old('department_id', $user->department_id) == $department->id ? 'selected' : ''); ?>>
                                                        <?php echo e($department->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <!-- SubDepartment Dropdown -->
                                    <div class="col-md-6" id="subdepartment-dropdown"
                                        style="<?php echo e($user->sub_department_id ? 'display: block;' : 'display: none;'); ?>">
                                        <div class="form-group">
                                            <label>Sub Department</label>
                                            <select class="form-control" name="sub_department_id">
                                                <option value="">Select a Sub Department</option>
                                                <?php $__currentLoopData = $subDepartment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subdepartment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($subdepartment->id); ?>"
                                                        <?php echo e(old('sub_department_id', $user->sub_department_id) == $subdepartment->id ? 'selected' : ''); ?>>
                                                        <?php echo e($subdepartment->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <!-- Position Dropdown -->
                                    <div class="col-md-6" id="position-dropdown" style="display: none;">
                                        <div class="form-group">
                                            <label>Position</label>
                                            <select  class="form-control" name="position">
                                                <option value="">Select a Position</option>
                                                <option value="Junior"
                                                    <?php echo e(old('position', $user->position) == 'Junior' ? 'selected' : ''); ?>>
                                                    Junior</option>
                                                <option value="Senior"
                                                    <?php echo e(old('position', $user->position) == 'Senior' ? 'selected' : ''); ?>>
                                                    Senior</option>
                                            </select>
                                        </div>
                                    </div>



                                    <!-- Schedule Dropdown -->
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Schedule</label>
                                            <select class="form-control <?php $__errorArgs = ['schedule_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="schedule_id" name="schedule_id" required>
                                                <option value="">Select a Schedule</option>
                                                <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($schedule->id); ?>"
                                                        <?php echo e(old('schedule_id', $user->schedule_id) == $schedule->id ? 'selected' : ''); ?>>
                                                        <?php echo e($schedule->title); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php if($errors->has('schedule_id')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('schedule_id')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <!-- Role Checkboxes -->
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Role</label>
                                            <div>
                                                <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <?php if($role != 'Super Admin'): ?>
                                                        <div class="u-cheque-btns">
                                                            <input type="checkbox" id="role_<?php echo e($role); ?>"
                                                                name="roles[]" value="<?php echo e($role); ?>"
                                                                <?php echo e(in_array($role, old('roles', $user->roles->pluck('name')->toArray())) ? 'checked' : ''); ?>>
                                                            <label
                                                                for="role_<?php echo e($role); ?>"><?php echo e($role); ?></label>
                                                        </div>
                                                    <?php else: ?>
                                                        <?php if(Auth::user()->hasRole('Super Admin')): ?>
                                                            <div class="u-cheque-btns">
                                                                <input type="checkbox" id="role_<?php echo e($role); ?>"
                                                                    name="roles[]" value="<?php echo e($role); ?>"
                                                                    <?php echo e(in_array($role, old('roles', $user->roles->pluck('name')->toArray())) ? 'checked' : ''); ?>>
                                                                <label
                                                                    for="role_<?php echo e($role); ?>"><?php echo e($role); ?></label>
                                                            </div>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <p>No roles available.</p>
                                                <?php endif; ?>
                                            </div>
                                            <?php if($errors->has('roles')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('roles')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-footer text-left">
                                    <button id="btn" class="btn btn-primary" type="submit">Update User</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('customJs'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const roleCheckboxes = document.querySelectorAll('input[name="roles[]"]');
            const departmentDropdown = document.getElementById('department-dropdown');
            const subDepartmentDropdown = document.getElementById('subdepartment-dropdown');
            const positionDropdown = document.getElementById('position-dropdown');

            roleCheckboxes.forEach(checkbox => {
                checkbox.addEventListener('change', function() {
                    if (this.checked && this.value === 'Employee') {
                        departmentDropdown.style.display = 'block';
                        subDepartmentDropdown.style.display = 'block';
                        positionDropdown.style.display = 'block';
                    } else if (!this.checked && this.value === 'Employee') {
                        departmentDropdown.style.display = 'none';
                        subDepartmentDropdown.style.display = 'none';
                        positionDropdown.style.display = 'none';
                    }
                });

                // If the page loads with "Employee" role already selected
                if (checkbox.checked && checkbox.value === 'Employee') {
                    departmentDropdown.style.display = 'block';
                    subDepartmentDropdown.style.display = 'block';
                    positionDropdown.style.display = 'block';
                }
            });

            // AJAX request to fetch sub-departments based on selected department
            document.querySelector('select[name="department_id"]').addEventListener('change', function() {
                const departmentId = this.value;
                fetch(`/subdepartments/${departmentId}`)
                    .then(response => response.json())
                    .then(data => {
                        const subDepartmentSelect = document.querySelector(
                            'select[name="sub_department_id"]');
                        subDepartmentSelect.innerHTML =
                            '<option value="">Select a Sub Department</option>';
                        data.forEach(subDepartment => {
                            subDepartmentSelect.innerHTML +=
                                `<option value="${subDepartment.id}">${subDepartment.name}</option>`;
                        });
                    });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO T430\Desktop\crm.w11stop.com\resources\views/users/edit.blade.php ENDPATH**/ ?>