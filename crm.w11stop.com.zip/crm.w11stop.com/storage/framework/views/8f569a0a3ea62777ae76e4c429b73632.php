

<?php $__env->startSection('title', 'Tickets'); ?>


<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="card">
            <div class="card-header">
                <h4><i   data-feather="message-square" class="  h-i"></i> Manage Tickets</h4>
                <a class="btn btn-primary" href="<?php echo e(route('tickets.create')); ?>">New Tickets</a>
            </div>
        </div>
    </section>
  
    <section class="section">
        <div class="card">
            <div class="card-body">
                <form  action="#"    >
                    <div class="row filter-container">

                        <div class="form-group col-md-2">
                            <label>Search</label>
                            <select name="user_id" class="form-control"                        >
                                <option selected disabled >User ID</option>
                        
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($userData->id); ?>">
                                        <?php echo e($userData->id); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                    
                        
                        <div class="form-group col-md-4">
                            <label>Subject</label>
                            <input type="text" name="subject" placeholder="Subject" class="form-control" value="<?php echo e(old('subject')); ?>"
                            required>
                        </div>
                        
                        <div class="form-group col-md-4">
                            <label>Department</label>
                            <select name="department" class="form-control">
                                <option selected disabled >Please Select Department</option>
                        
                                <?php $__currentLoopData = $Departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($Department->id); ?>">
                                        <?php echo e($Department->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                    
                        <div class="form-group col-md-2">
                            <label>Ticket Status</label>
                            <select name="department" class="form-control" >
                                <option selected disabled >Select</option>
                                    <option value="open">
                                        Open
                                    </option>
                                    <option value="in-progress">
                                        In Progress
                                    </option>
                                    <option value="closed">
                                        Closed
                                    </option>
                            </select>
                        </div>

                        <div class="form-group col-md-3">
                            <label>Ticket ID</label>
                            <input type="text" name="ticket_id" placeholder="Ticket ID" class="form-control" value="<?php echo e(old('ticket_id')); ?>"
                            required>
                        </div>
                    
                        <div class="form-group col-md-4">
                            <label>Added By</label>

                            <select name="ticket_id" class="form-control"                        >
                            <option selected disabled >Select </option>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($userData->id); ?>">
                                        <?php echo e($userData->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-md-3">
                            <div class="flex-button-2">
                                <div>
                                    <button type="submit" class="btn btn-primary">Search</button>
                                </div>
                            </div>
                        </div>
                        
                    </div><!--row end -->
                </form>
            </div>  
        </div>
    </section>

    <section class="section">
        <div class="section-body">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped" id="table-1">
                                    <thead>
                                        <tr>
                                            <th class="text-center">S#</th>
                                            <th class="text-center">Department</th>
                                            <th class="text-center">Subject</th>
                                            <th class="text-center">Priority</th>
                                            <th class="text-center">Added By</th>
                                            <th class="text-center">Status</th>
                                            <th class="text-center">Created At</th>
                                            <th class="text-center">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="text-center"><?php echo e($ticket->id); ?></td>
                                                <td class="text-center">
                                                    <?php if($ticket->departments->isNotEmpty()): ?>
                                                        <?php echo e($ticket->departments->pluck('name')->implode(', ')); ?>

                                                    <?php else: ?>
                                                        N/A
                                                    <?php endif; ?>
                                                </td>
                                                
                                                <td class="text-center"><?php echo e($ticket->subject); ?></td>


                                                <td class="text-center">
                                                    
                                                    <span class="badge badge-shadow 
                                                    <?php if($ticket->priority  == 'High'): ?>
                                                     badge-danger 
                                                    <?php elseif($ticket->priority  == 'Medium'): ?>
                                                        badge-primary
                                                    <?php else: ?>
                                                        badge-success
                                                    <?php endif; ?>
                                                    ">
                                                        
                                                        <?php echo e($ticket->priority); ?>

                                                    </span>
                                                
                                                
                                                </td>

                                                <td class="text-center"><?php echo e($ticket->user->name); ?></td>
                                                
                                                <td class="text-center">
                                                    
                                                    <span class="badge badge-shadow 
                                                        <?php if($ticket->status == 'open' ): ?>
                                                        badge-success  
                                                        <?php elseif($ticket->status == 'in-progress' ): ?>
                                                        badge-primary  
                                                        <?php else: ?>
                                                        badge-danger 
                                                        <?php endif; ?>
                                                    ">
                                                        <?php echo e($ticket->status); ?>

                                                    </span>
                                                </td>
                                               
                                                <td class="text-center"><?php echo e($ticket->created_at->format('d M Y')); ?></td>
                                                <td class="just-flex">
                                                    <form class="my-0-mx-auto"
                                                        action="<?php echo e(route('tickets.destroy', $ticket->id)); ?>"
                                                        method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <table>
                                                            <tr>
                                                                <td>
                                                                    <a href="<?php echo e(route('tickets.edit', $ticket->id)); ?>"
                                                                        class="btn btn-primary btn-md">
                                                                        <i class="fa-regular fa-eye h-i-2"></i>
                                                                    </a>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Farhan ALi\Downloads\new portal\crm.w11stop.com\resources\views/admin/tickets/index.blade.php ENDPATH**/ ?>