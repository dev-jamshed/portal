

<?php $__env->startSection('title', 'Manage Logo Requirements'); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="card">
            <div class="card-header">
                <h4><i   data-feather="figma" class=" h-i"></i> Manage Logo Requirements</h4>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-logo-requirement')): ?>
                    <a class="btn btn-primary" href="<?php echo e(route('logo_requirements.create')); ?>">   Add New Requirement</a>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <section class="section">
        <div class="section-body">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped" id="table-1">
                                    <thead>
                                        <tr>
                                            <th class="text-center">S#</th>
                                            <th>Company Name</th>
                                            <th>Products</th>
                                            <th>Logo Name</th>
                                            <th>Tagline</th>
                                            
                                            
                                            
                                            <th>Logo Type</th>
                                            <th>Reference File</th>
                                            <th class="text-center">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $logoRequirements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requirement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($requirement->id); ?></td>
                                                <td><?php echo e($requirement->company_name); ?></td>
                                                <td><?php echo e($requirement->products); ?></td>
                                                <td><?php echo e($requirement->logo_name); ?></td>
                                                <td><?php echo e($requirement->tagline); ?></td>
                                                
                                                
                                                
                                                <td><?php echo e($requirement->logotype); ?></td>
                                                <td>
                                                    <?php if($requirement->reference_file): ?>
                                                        <a href="<?php echo e(asset($requirement->reference_file)); ?>"
                                                            target="_blank">View File</a>
                                                    <?php else: ?>
                                                        N/A
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <div class="btn-group">
                                                        <a href="<?php echo e(route('logoRecruitment.edit', $requirement->id)); ?>" class="btn btn-secondary btn-sm"><i class="fa-regular fa-eye h-i-2"></i></a>


                                                        
                                                        
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('customJs'); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Farhan ALi\Downloads\new portal\crm.w11stop.com\resources\views/admin/logo_requirement/index.blade.php ENDPATH**/ ?>