

<?php $__env->startSection('title', 'Create Ticket'); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-body">
            <div class="row">
                <div class="col-12">
                    <div class="card">

                        <div class="card-header d-flex align-items-center justify-content-between py-3">
                            <h4><i class="fa-regular fa-ticket h-i"></i> Create Ticket</h4>
                            <a href="<?php echo e(route('tickets.index')); ?>" class="btn btn-primary">Back</a>
                        </div>

                        <div class="card-body">
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                                
                            <form action="<?php echo e(route('tickets.store')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>

                                <div class="row">
                                    
                                    <div class="form-group col-md-6">
                                        <label>Priority</label>
                                        <select name="priority" class="form-control" required>
                                            <option value="low" <?php echo e(old('priority') == 'low' ? 'selected' : ''); ?>>Low
                                            </option>
                                            <option value="medium" <?php echo e(old('priority') == 'medium' ? 'selected' : ''); ?>>Medium
                                            </option>
                                            <option value="high" <?php echo e(old('priority') == 'high' ? 'selected' : ''); ?>>High
                                            </option>
                                        </select>
                                    </div>

                                    <!-- Multiple Department Selection -->
                                    <div class="form-group col-md-6">
                                        <label>Departments</label>
                                        <select id="department_id" name="department_ids[]" class="form-control"
                                            >
                                    
                                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($department->id); ?>"
                                                    <?php echo e(in_array($department->id, old('department_ids', [])) ? 'selected' : ''); ?>>
                                                    <?php echo e($department->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <!-- Multiple Sub Department Selection -->
                                    <?php if(in_array('sub_department_id', $fields)): ?>
                                    <div class="form-group col-md-6">
                                        <label>Sub Departments</label>
                                        <select id="sub_department_id" name="sub_department_ids[]"
                                            class="form-control " >
                                            <?php $__currentLoopData = $subDepartments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subDepartment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($subDepartment->id); ?>"
                                                    <?php echo e(in_array($subDepartment->id, old('sub_department_ids', [])) ? 'selected' : ''); ?>>
                                                    <?php echo e($subDepartment->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <?php endif; ?>

                                    
                                    <!-- Common fields -->
                                    <div class="form-group col-md-6">
                                        <label>Subject</label>
                                        <input type="text" name="subject" class="form-control" value="<?php echo e(old('subject')); ?>"
                                            required>
                                    </div>

                                    <div class="form-group col-md-12">
                                        <label>Message</label>
                                        <textarea id="description" name="description" class="form-control"><?php echo e(old('description')); ?></textarea>
                                    </div>

                                    <!-- Multiple Employee Selection -->
                                    <?php if(in_array('employee_id', $fields)): ?>
                                    <div class="form-group col-md-6">
                                        <label>CC</label>
                                        <select id="employee_id" name="employee_ids[]" class="form-control select2"
                                            multiple>
                                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($employee->id); ?>"
                                                    <?php echo e(in_array($employee->id, old('employee_ids', [])) ? 'selected' : ''); ?>>
                                                    <?php echo e($employee->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                <?php endif; ?>


                                    

                                    <!-- Conditional fields for Sales department -->
                                    <?php if($user->department && $user->department->name === 'Sales'): ?>


                                        <div class="form-group col-md-6">
                                            <label>Client</label>
                                            <select name="client_id" id="clients" class="form-control">
                                                <option value="">Select Client</option>
                                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($client->id); ?>"><?php echo e($client->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label>client Name</label>
                                            <input type="text" required id="c_name" name="c_name" class="form-control"
                                                value="">
                                        </div>

                                        <div class="form-group col-md-6">
                                            <label>client address</label>
                                            <input type="text" required id="c_address" name="c_address" class="form-control"
                                                value="">
                                        </div>



                                        <div class="form-group col-md-6">
                                            <label>client Company_name</label>
                                            <input type="text" required id="c_company_name" name="c_company_name"
                                                class="form-control" value="">
                                        </div>

                                        <div class="form-group col-md-6">
                                            <label>client phone no</label>
                                            <input type="tel" required id="c_mobile_number" name="c_mobile_number"
                                                class="form-control" value="">
                                        </div>

                                        <div class="form-group col-md-6">
                                            <label>client email</label>
                                            <input type="email" required id="c_email" name="c_email" class="form-control"
                                                value="">
                                        </div>


                                        <div class="form-group col-md-6">
                                            <label>Country:</label>
                                            <select required id="country" name="c_country" class="selectpicker form-control"
                                                data-style="py-0">
                                                <option value="">Select Country</option>
                                                <option value="Pakistan">Pakistan</option>
                                                <option value="India">India</option>
                                                <option value="USA">USA</option>
                                                <option value="Uk">Uk</option>
                                                <option value="Africa">Africa</option>
                                            </select>
                                        </div>
                                    <?php endif; ?>

                                    <?php if($showProjectFields): ?>
                                        <div class="form-group col-md-6">
                                            <label>Project Name</label>
                                            <input type="text" name="project_name" class="form-control"
                                                value="<?php echo e(old('project_name')); ?>" required>
                                        </div>

                                        <div class="form-group col-md-6">
                                            <label>Project Deadline</label>
                                            <input type="date" name="project_deadline" class="form-control"
                                                value="<?php echo e(old('project_deadline')); ?>" required>
                                        </div>
                                    <?php endif; ?>
    
                                    <?php if($showProjectFields): ?>
                                        <div class="form-group col-md-6">
                                            <label>Price</label>
                                            <input type="text" name="price" class="form-control"
                                                value="<?php echo e(old('price')); ?>">
                                        </div>
                                    <?php endif; ?>

                                
                                    <!-- File Attachments -->
                                    <div class="form-group col-md-6">
                                        <label>Attachments</label>
                                        <input type="file" name="attachments[]" class="form-control" multiple>
                                    </div>


                                    <div class="col-md-12">
                                        <button type="submit" class="btn btn-primary">Create Ticket</button>
                                    </div>


                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('customJs'); ?>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const departmentDropdown = document.getElementById('department_id');
            const subDepartmentDropdown = document.getElementById('sub_department_id');
            const employeeDropdown = document.getElementById('employee_id');

            // Fetch sub-departments based on selected department
            departmentDropdown.addEventListener('change', function() {
                const departmentId = this.value;
                if (departmentId) {
                    fetch(`/get-sub-departments/${departmentId}`)
                        .then(response => response.json())
                        .then(data => {
                            subDepartmentDropdown.innerHTML =
                                '<option value="">Select a Sub Department</option>';
                            data.forEach(subDept => {
                                subDepartmentDropdown.innerHTML +=
                                    `<option value="${subDept.id}">${subDept.name}</option>`;
                            });
                        })
                        .catch(error => console.error('Error:', error));
                }
            });
            $(document).ready(function() {
                $('#clients').select2({
                    placeholder: "Select clients", // Placeholder text
                    allowClear: true, // Option to clear the selection
                    
                });
                // $('#department_id').select2({
                //     placeholder: "Select departments", // Placeholder text
                //     allowClear: true // Option to clear the selection
                // });
                // $('#sub_department_id').select2({
                //     placeholder: "Select Sub departments", // Placeholder text
                //     allowClear: true // Option to clear the selection
                // });
                $('#employee_id').select2({
                    placeholder: "Select CC", // Placeholder text
                    allowClear: true // Option to clear the selection
                });
            });
            
            $('#clients').on('select2:select', function(e) {
                var selectedOption = $(e.currentTarget).find("option:selected");
                var clientId = selectedOption.val();
                // Fetch client record using AJAX
                $.ajax({
                    url: '<?php echo e(route('client.fetch')); ?>',
                    type: 'GET',
                    data: {
                        clientId: clientId
                    },
                    success: function(response) {
                        console.log(response);
                        // Populate input fields with fetched data
                        $('#c_name').val(response.name);
                        // $('#lname').val(response.last_name);
                        $('#c_address').val(response.address);
                        $('#c_company_name').val(response.company_name);
                        $('#c_mobile_number').val(response.mobile_number);
                        $('#c_email').val(response.email);
                        // Auto-fill client's country
                        $('[name="c_country"]').val(response.country).trigger('change');

                    },
                    error: function(xhr, status, error) {
                        console.error(error);
                    }
                });
            });

            tinymce.init({
                selector: '#description',
            });


        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Farhan ALi\Downloads\new portal\crm.w11stop.com\resources\views/admin/tickets/create.blade.php ENDPATH**/ ?>