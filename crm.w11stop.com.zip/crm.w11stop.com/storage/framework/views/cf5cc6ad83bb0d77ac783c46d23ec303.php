<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logo Requirement Specification</title>

    <!-- Bootstrap Link -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/style.css')); ?>">
    <script src="https://js.stripe.com/v3/"></script>
</head>
<body>
    <div class="container">
        <div class="content-container">
            <div class="logo">
                <img src="<?php echo e(asset('frontend/images/logo-main.png')); ?>" alt="Logo">
            </div>

            <!-- Modal Terms Conditions -->
            <div class="modal fade" id="termsConditions" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Terms Conditions</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <p>Terms and Conditions Here...</p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="submit-btn" data-bs-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal Privacy Policy -->
            <div class="modal fade" id="privacyPolicy" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Privacy Policy</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <p>Privacy Policy Here...</p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="submit-btn" data-bs-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="checkout-wrapper">
                <form action="<?php echo e(route('logoRecruitment')); ?>" method="post" id="payment-form" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <!-- Heading -->
                    <div class="heading">
                        <h3>Logo Requirement Specification</h3>
                    </div>

                    <!-- Input Fields -->
                    <div class="row mx-4 my-3">
                        <div class="col-12">
                            <p class="mini-heading">Fill in the form to help us design your logo. Provide accurate information for the best results.</p>
                        </div>
                    </div>

                    <!-- Logo Requirement -->
                    <div class="heading">
                        <h3>Logo Requirement</h3>
                    </div>
                    <div class="row mx-4 my-3">
                        <div class="col-md-6">
                            <div class="input-div">
                                <label>Business/Company Name:</label>
                                <input required type="text" name="company_name" placeholder="Business/Company...">
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="input-div">
                                <label>Main Products | Services:</label>
                                <input required type="text" name="products" placeholder="Products / Services...">
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="input-div">
                                <label>Exact name to be appeared on logo:</label>
                                <input required type="text" name="logo_name" placeholder="Exact Name...">
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="input-div">
                                <label>Any Tagline/Slogan?</label>
                                <input required type="text" name="tagline" placeholder="Slogan...">
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="input-div">
                                <label>Do you have any existing website?</label>
                                <input required type="text" name="website" placeholder="Reference Website URL...">
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="input-div">
                                <label>Company/Factory Address:</label>
                                <input required type="text" name="company_address" placeholder="Company/Factory Address...">
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="input-div">
                                <label>Do you have any other requirements or suggestions?</label>
                                <input required type="text" name="suggestions" placeholder="Suggestions...">
                            </div>
                        </div>
                    </div>

                    <!-- Design Preference -->
                    <div class="heading">
                        <h3>Please select the design you like</h3>
                    </div>

                    <div class="row mx-4 my-3">
                        <!-- Abstracted Logo -->
                        <div class="col-md-12">
                            <div class="logo_type_container">
                                <div class="row">
                                    <div class="col-md-6 col-sm-3">
                                        <div class="flex_1">
                                            <label class="logo_label" for="Abstracted">Abstracted Logo</label>
                                            <input type="radio" id="Abstracted" name="logotype">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-sm-9">
                                        <div class="row">
                                            <div class="col-md-6"><img class="logo-type" src="<?php echo e(asset('frontend/images/Abstract logo/1.jpg')); ?>" alt="Abstract Logo 1"></div>
                                            <div class="col-md-6"><img class="logo-type" src="<?php echo e(asset('frontend/images/Abstract logo/2.png')); ?>" alt="Abstract Logo 2"></div>
                                            <div class="col-md-6"><img class="logo-type" src="<?php echo e(asset('frontend/images/Abstract logo/3.webp')); ?>" alt="Abstract Logo 3"></div>
                                            <div class="col-md-6"><img class="logo-type" src="<?php echo e(asset('frontend/images/Abstract logo/4.jpg')); ?>" alt="Abstract Logo 4"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Combination Based Logo -->
                        <!-- Similar structure for other logo types -->
                    </div>

                    <!-- File Upload -->
                    <div class="col-md-6 mt-3">
                        <div class="input-div">
                            <label>Any Reference files or existing Logo? (PNG, JPG):</label>
                            <input type="file" name="reference_files" style="padding: 4.4px;">
                        </div>
                    </div>

                    <!-- Agreement and Submit -->
                    <div class="col-12 my-2">
                        <div class="mb-2">
                            <input type="checkbox" id="agreeCheck" required>
                            <label style="cursor: pointer;font-size:12px" for="agreeCheck">I agree to the <a href="#" data-bs-toggle="modal" data-bs-target="#termsConditions">terms and conditions</a> and <a href="#" data-bs-toggle="modal" data-bs-target="#privacyPolicy">privacy policy</a></label>
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-PQ7xPjjjEWLKN3j6OH5zZ6rYhr7T4MtV9S7Hk8E4hmRfPj2O8zDvcDqN0t5c5coC" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-8dK2yC5Ic+OWfMbjj4mnbjD8g8i2y5VV5mkx8QGrW1F5N3J8wJ5tIUR7LP72h1Sv8" crossorigin="anonymous"></script>
</body>
</html>
<?php /**PATH C:\Users\LENOVO T430\Desktop\crm.w11stop.com\resources\views/admin/forms/logo_form.blade.php ENDPATH**/ ?>