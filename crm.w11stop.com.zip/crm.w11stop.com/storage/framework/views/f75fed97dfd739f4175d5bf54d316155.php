 

 

 <?php $__env->startSection('title', 'Manage Users'); ?>

 <?php $__env->startSection('content'); ?>


     <section class="section">
         <div class="card">
             <div class="card-header">
                 <h4><i class="fa-regular fa-user h-i"></i> Manage Users</h4>
                 <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-user')): ?>
                     <a class="btn btn-primary" href="<?php echo e(route('users.create')); ?>"> Add New
                         User</a>
                 <?php endif; ?>
             </div>
         </div>
     </section>


     <section class="section">
         <div class="section-body">
             <div class="row">
                 <div class="col-12">
                     <div class="card">
                         <div class="card-body">
                             <div class="table-responsive">
                                 <table class="table table-striped" id="table-1">
                                     <thead>
                                         <tr>
                                             <th class="text-center">
                                                 S#
                                             </th>
                                             <th>Name</th>
                                             <th>Email</th>
                                             <th>Deparment</th>
                                             <th>Roles</th>

                                             <th class="text-center">Actions</th>
                                         </tr>
                                     </thead>
                                     <tbody>
                                         <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <tr>
                                                 <td><?php echo e($user->id); ?></td>
                                                 <td><?php echo e($user->name); ?></td>
                                                 <td><?php echo e($user->email); ?></td>
                                                 <td>

                                                    <span class="badge badge-primary badge-shadow"> <?php echo e($user->department?->name ?? 'N/A'); ?></span>

                                                   
                                                
                                                </td>

                                                 <td>
                                                     <?php $__empty_1 = true; $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                         
                                                         <?php if($loop->last): ?>
                                                         <span class="badge badge-primary badge-shadow"><?php echo e($role); ?></span>
                                                     <?php endif; ?>
                                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                     <?php endif; ?>
                                                 </td>
                                                 <td>
                                                     <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="post">
                                                         <table>
                                                             <tr>
                                                                 <?php echo csrf_field(); ?>
                                                                 <?php echo method_field('DELETE'); ?>
                                                                 <?php if(in_array('super-admin', $user->getRoleNames()->toArray() ?? [])): ?>
                                                                     <?php if(Auth::user()->hasRole('super-admin')): ?>
                                                                         <td>

                                                                             <a href="<?php echo e(route('users.edit', $user->id)); ?>"
                                                                                 class="btn btn-primary btn-sm"><i
                                                                                     class="fa-regular fa-pen-to-square"></i></a>
                                                                         </td>
                                                                     <?php endif; ?>
                                                                 <?php else: ?>
                                                                     <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-user')): ?>
                                                                         <td>
                                                                             <a href="<?php echo e(route('users.edit', $user->id)); ?>"
                                                                                 class="btn btn-primary btn-sm"><i
                                                                                     class="fa-regular fa-pen-to-square"></i></a>
                                                                         </td>
                                                                     <?php endif; ?>

                                                                     <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-user')): ?>
                                                                         <?php if(Auth::user()->id != $user->id): ?>
                                                                             <td>
                                                                                 <button type="submit"
                                                                                     class="btn btn-danger btn-sm  "
                                                                                     onclick="return confirm('Do you want to delete this user?');"><i
                                                                                         class="fa-regular fa-trash"></i></button>
                                                                             </td>
                                                                         <?php endif; ?>
                                                                     <?php endif; ?>
                                                                 <?php endif; ?>
                                                             </tr>
                                                         </table>
                                                     </form>
                                                 </td>
                                             </tr>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     </tbody>
                                 </table>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
     </section>
 <?php $__env->stopSection(); ?>
 <?php $__env->startSection('customJs'); ?>

 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Farhan ALi\Downloads\new portal\crm.w11stop.com\resources\views/users/index.blade.php ENDPATH**/ ?>