 








<?php $__env->startSection('title','  Role Information'); ?>

<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="section-body">
      <div class="row">


        <div class="col-12">
          <div class="card">
            <div class="card-header d-flex align-items-center justify-content-between py-3 ">
              <h4>  Role Information</h4>
              <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-primary">Back</a>
            </div>
          </div>
        </div>


        <div class="col-12">
          <div class="card">

            <div class="card-body">


                <div class="mb-3 row">
                    <label for="name" class="col-md-4 col-form-label text-md-end text-start"><strong>Name:</strong></label>
                    <div class="col-md-6" style="line-height: 35px;font-weight:600">
                        <?php echo e($role->name); ?>

                    </div>
                </div>

                <div class="mb-3 row">
                    <label for="roles" class="col-md-4 col-form-label text-md-end text-start"><strong>Permissions:</strong></label>
                    <div class="col-md-6" style="line-height: 35px;">
                        <?php if($role->name=='Super Admin'): ?>
                            <span class="badge bg-primary">All</span>
                        <?php else: ?>
                            <?php $__empty_1 = true; $__currentLoopData = $rolePermissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <span class="badge badge-primary badge-shadow"><?php echo e($permission->name); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>

          </div>
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('customJs'); ?>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Farhan ALi\Downloads\new portal\crm.w11stop.com\resources\views/roles/show.blade.php ENDPATH**/ ?>