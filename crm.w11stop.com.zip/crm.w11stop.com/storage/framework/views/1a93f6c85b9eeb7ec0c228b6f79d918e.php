<?php $__env->startSection('title', 'Edit Schedule'); ?>

<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="card">
        <div class="card-header">
            <h4><i class="fa-solid fa-pen-to-square h-i"></i> Edit Schedule</h4>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('schedules.update', $schedule->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group">
                    <label for="title">Title</label>
                    <input type="text" name="title" class="form-control" value="<?php echo e($schedule->title); ?>" required>
                </div>
                <div class="form-group">
                    <label for="start_datetime">Start DateTime</label>
                    <input type="time" name="start_datetime" class="form-control" value="<?php echo e($schedule->start_datetime); ?>" required>
                </div>
                <div class="form-group">
                    <label for="end_datetime">End DateTime</label>
                    <input type="time" name="end_datetime" class="form-control" value="<?php echo e($schedule->end_datetime); ?>" required>
                </div>
                <div class="form-group">
                    <label for="late_time">Late Time</label>
                    <input type="time" name="late_time" class="form-control" value="<?php echo e($schedule->late_time); ?>" required>
                </div>
                <div class="form-group">
                    <label for="half_day_time">Half Day Time</label>
                    <input type="time" name="half_day_time" class="form-control" value="<?php echo e($schedule->half_day_time); ?>" required>
                </div>
                <button type="submit" class="btn btn-primary">Update</button>
            </form>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO T430\Desktop\crm.w11stop.com\resources\views/admin/schedules/edit.blade.php ENDPATH**/ ?>