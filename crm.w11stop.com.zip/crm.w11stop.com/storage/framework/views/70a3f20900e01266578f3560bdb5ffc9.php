

<?php $__env->startSection('title', 'Edit Ticket'); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-body">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header d-flex align-items-center justify-content-between py-3">
                            <h4><i class="fa-regular fa-ticket h-i"></i> Edit Ticket</h4>
                            <a href="<?php echo e(route('tickets.index')); ?>" class="btn btn-primary">Back</a>
                        </div>
                        <div class="card-body">
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>

                            <form action="<?php echo e(route('tickets.update', $ticket->id)); ?>" method="POST"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <?php
                                    // dd([
                                    //     'hasSalesRole' => $user->hasRole('Sales'),
                                    //     'hasManagerRole' => $user->hasRole('manager'),
                                    // ]);
                                ?>
                                <!-- Display fields based on department and user role -->


                                <?php if(
                                    $user->hasRole(['Manager', 'Super Admin']) ||
                                        ($user->department && $user->department->name === 'Sales' && $ticket->created_by == $user->id)): ?>
                                    <div class="form-group">
                                        <label>Price</label>
                                        <input type="text" name="price" class="form-control"
                                            value="<?php echo e($ticket->price); ?>" disabled>
                                    </div>
                                <?php endif; ?>

                                <!-- Subject -->
                                <div class="form-group">
                                    <label>Subject</label>
                                    <input type="text" name="subject" class="form-control" value="<?php echo e($ticket->subject); ?>"
                                        disabled>
                                </div>

                                <!-- Description -->
                                <div class="form-group">
                                    <label>Description</label>
                                    <textarea id="description" class="form-control" rows="5" readonly><?php echo $ticket->description; ?></textarea>
                                </div>

                                <?php if(
                                    ($user->department && $user->hasRole('Sales')) ||
                                        ($user->hasRole('manager') && $ticket->user_id == Auth::user()->id)): ?>
                                    <!-- Client Details -->
                                    <div class="form-group">
                                        <label>Client Name</label>
                                        <input type="text" id="c_name" name="c_name" class="form-control"
                                            value="<?php echo e($ticket->client->name); ?>" disabled>
                                    </div>

                                    
                                <?php endif; ?>


                                <!-- Check if Project Name is not null or empty -->
                                <?php if(!empty($ticket->project_name)): ?>
                                    <div class="form-group">
                                        <label>Project Name</label>
                                        <input type="text" name="project_name" class="form-control"
                                            value="<?php echo e(old('project_name', $ticket->project_name)); ?>" required>
                                    </div>
                                <?php endif; ?>

                                <!-- Check if Project Deadline is not null or empty -->
                                <?php if(!empty($ticket->project_deadline)): ?>
                                    <div class="form-group">
                                        <label>Project Deadline</label>
                                        <input type="date" name="project_deadline" class="form-control"
                                            value="<?php echo e(old('project_deadline', $ticket->project_deadline)); ?>" required>
                                    </div>
                                <?php endif; ?>

                                <!-- Departments -->
                                <div class="form-group">
                                    <label>Departments</label>
                                    <select id="department_id" name="department_ids[]" class="form-control select2"
                                        multiple>
                                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($department->id); ?>"
                                                <?php if(in_array($department->id, $ticket->departments->pluck('id')->toArray())): ?> selected <?php endif; ?>>
                                                <?php echo e($department->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>



                                <!-- Sub Departments -->
                                <div class="form-group">
                                    <label>Sub Departments</label>
                                    <select id="sub_department_id" name="sub_department_ids[]" class="form-control select2"
                                        multiple>
                                        <?php $__currentLoopData = $subDepartments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subDepartment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($subDepartment->id); ?>"
                                                <?php if(in_array($subDepartment->id, $ticket->subDepartments->pluck('id')->toArray())): ?> selected <?php endif; ?>>
                                                <?php echo e($subDepartment->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>


                                <!-- Multiple Employee Selection -->
                                <?php if(in_array('employee_id', $fields)): ?>
                                    <div class="form-group">
                                        <label>Assign to</label>
                                        <select id="employee_id" name="employee_ids[]" class="form-control select2"
                                            multiple>
                                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($employee->id); ?>"
                                                    <?php echo e(in_array($employee->id, $ticket->employees->pluck('id')->toArray()) ? 'selected' : ''); ?>>
                                                    <?php echo e($employee->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                <?php endif; ?>

                                <!-- Priority -->
                                <div class="form-group">
                                    <label>Priority</label>
                                    <select name="priority" class="form-control" disabled>
                                        <option value="low" <?php echo e($ticket->priority == 'low' ? 'selected' : ''); ?>>Low
                                        </option>
                                        <option value="medium" <?php echo e($ticket->priority == 'medium' ? 'selected' : ''); ?>>Medium
                                        </option>
                                        <option value="high" <?php echo e($ticket->priority == 'high' ? 'selected' : ''); ?>>High
                                        </option>
                                    </select>
                                </div>

                                <!-- Status -->
                                <div class="form-group">
                                    <label>Status</label>
                                    <select name="status" class="form-control">
                                        <option value="open" <?php echo e($ticket->status == 'open' ? 'selected' : ''); ?>>Open
                                        </option>
                                        <option value="in-progress"
                                            <?php echo e($ticket->status == 'in-progress' ? 'selected' : ''); ?>>In Progress</option>
                                        <option value="closed" <?php echo e($ticket->status == 'closed' ? 'selected' : ''); ?>>Closed
                                        </option>
                                    </select>
                                </div>


                                <div class="card mb-4">
                                    <div class="card-header">
                                        <h5>Comments</h5>
                                    </div>
                                    <div class="card-body">
                                        <?php $__currentLoopData = $ticket->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="comment mb-4 p-3 border rounded">
                                            <div class="d-flex justify-content-between align-items-center mb-2">
                                                <h5 class="mb-0">Comment by <?php echo e($comment->user->name); ?></h5>
                                                <small class="text-muted"><?php echo e($comment->created_at->format('d M Y, h:i A')); ?></small>
                                            </div>
                                            <div id="comment_<?php echo e($comment->id); ?>" class="comment-content p-2 border rounded bg-light" style="max-height: 150px; overflow-y: auto;">
                                                <?php echo $comment->comment; ?>

                                            </div>
                                    
                                            <!-- Attachments for this comment -->
                                            <?php if($comment->attachments->count()): ?>
                                                <div class="mt-2">
                                                    <label>Attachments:</label>
                                                    <div class="attachment-list">
                                                        <?php $__currentLoopData = $comment->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="attachment-item">
                                                                <a href="<?php echo e(route('attachments.comment.download', $attachment->id)); ?>" class="btn btn-secondary btn-sm" target="_blank">
                                                                    <?php echo e($attachment->file_name); ?>

                                                                </a>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    


                                    </div>
                                </div>


                                <!-- Comments -->
                                <div class="form-group">
                                    <label>Add Comment</label>
                                    <textarea id="comment" name="comment" class="form-control"><?php echo e(old('comment')); ?></textarea>
                                </div>



                                <!-- Attachments -->
                                <div class="form-group">
                                    <label>Attachments </label>
                                    <div class="attachment-list">
                                        <?php if($ticket->attachments->count()): ?>
                                            <a href="<?php echo e(route('attachments.downloadAll', $ticket->id)); ?>"
                                                class="btn btn-primary">
                                                Download All Attachments
                                            </a>
                                        <?php endif; ?>
                                        <?php $__currentLoopData = $ticket->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="attachment-item">
                                                <a href="<?php echo e(route('attachments.download', $attachment->id)); ?>"
                                                    class="btn btn-secondary btn-sm" target="_blank">
                                                    <?php echo e($attachment->file_name); ?>

                                                </a>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    
                                    <input type="file" name="comment_attachments[]" class="form-control" multiple>
                                </div>

                                <button type="submit" class="btn btn-primary">Update Ticket</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('customJs'); ?>
    <script>
        $(document).ready(function() {
            $('#clients').select2({
                placeholder: "Select clients", // Placeholder text
                allowClear: true // Option to clear the selection
            });
            $('#department_id').select2({
                placeholder: "Select departments", // Placeholder text
                allowClear: true // Option to clear the selection
            });
            $('#sub_department_id').select2({
                placeholder: "Select Sub departments", // Placeholder text
                allowClear: true // Option to clear the selection
            });
            $('#employee_id').select2({
                placeholder: "Select CC", // Placeholder text
                allowClear: true // Option to clear the selection
            });
        });
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize TinyMCE for displaying existing comments in read-only mode
            tinymce.init({
                selector: '#description',
                menubar: false, // Hide menubar
                toolbar: false, // Hide toolbar
                readonly: true, // Make it read-only
                setup: function(editor) {
                    editor.on('init', function() {
                        editor.getBody().setAttribute('contenteditable',
                            false); // Ensure it's not editable
                    });
                }
            });

            // Initialize TinyMCE for the new comment field (editable)
            tinymce.init({
                selector: '#comment',
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO T430\Desktop\crm.w11stop.com\resources\views/admin/tickets/edit.blade.php ENDPATH**/ ?>