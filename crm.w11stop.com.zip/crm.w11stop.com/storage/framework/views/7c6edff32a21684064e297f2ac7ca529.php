<?php $__env->startSection('title', 'Manage Schedules'); ?>

<?php $__env->startSection('content'); ?>

    <section class="section">
        <div class="card">
            <div class="card-header">
                <h4><i class="fa-solid fa-clipboard-question h-i"></i> Manage Schedules</h4>
                <a class="btn btn-primary" href="<?php echo e(route('schedules.create')); ?>"> <i class="fa-solid fa-plus h-i-2"></i>Add New Schedule</a>
            </div>
        </div>
    </section>

    <section class="section">
        <div class="section-body">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped" id="table-1">
                                    <thead>
                                        <tr>
                                            <th class="text-center">S#</th>
                                            <th class="text-center">Title</th>
                                            <th class="text-center">Start DateTime</th>
                                            <th class="text-center">End DateTime</th>
                                            <th class="text-center">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td class="text-center"><?php echo e($schedule->id); ?></td>
                                            <td class="text-center"><?php echo e($schedule->title); ?></td>
                                            <td class="text-center"><?php echo e($schedule->start_datetime); ?></td>
                                            <td class="text-center"><?php echo e($schedule->end_datetime); ?></td>
                                            <td class="just-flex">
                                                <form class="my-0-mx-auto" action="<?php echo e(route('schedules.destroy', $schedule->id)); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>

                                                    <table>
                                                        <tr>
                                                            
                                                            <td>
                                                                <a href="<?php echo e(route('schedules.edit', $schedule->id)); ?>" class="btn btn-primary btn-sm"><i class="fa-regular fa-pen-to-square"></i></a>
                                                            </td>
                                                            

                                                            
                                                            <td>
                                                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Do you want to delete this Record?');"><i class="fa-regular fa-trash"></i></button>
                                                            </td>
                                                            
                                                        </tr>
                                                    </table>
                                                </form>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="5" class="text-center">No Schedules Found</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO T430\Desktop\crm.w11stop.com\resources\views/admin/schedules/index.blade.php ENDPATH**/ ?>