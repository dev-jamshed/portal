

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
      
        <div class="row">
            

            
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <!--<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pr-0 pt-3">-->
                                <div class="card-content">
                                    <h5 class="font-15">Open Tickets</h5>
                                    <h2 class="mb-3 font-18"><?php echo e($openTicketsCount); ?></h2>
                                </div>
                                <!--</div>-->
                                <!--<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pl-0">-->
                                <!--    <div class="banner-img">-->
                                <!--        <img src="<?php echo e(asset('admin/assets/img/banner/4.png')); ?>" alt="">-->
                                <!--    </div>-->
                                <!--</div>-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <!--<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pr-0 pt-3">-->
                                <div class="card-content">
                                    <h5 class="font-15">In Progress Tickets</h5>
                                    <h2 class="mb-3 font-18"><?php echo e($progressTicketsCount); ?></h2>
                                </div>
                                <!--</div>-->
                                <!--<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pl-0">-->
                                <!--    <div class="banner-img">-->
                                <!--        <img src="<?php echo e(asset('admin/assets/img/banner/4.png')); ?>" alt="">-->
                                <!--    </div>-->
                                <!--</div>-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <!--<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pr-0 pt-3">-->
                                <div class="card-content">
                                    <h5 class="font-15">Closed Tickets</h5>
                                    <h2 class="mb-3 font-18"><?php echo e($closedTicketsCount); ?></h2>
                                </div>
                                <!--</div>-->
                                <!--<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pl-0">-->
                                <!--    <div class="banner-img">-->
                                <!--        <img src="<?php echo e(asset('admin/assets/img/banner/4.png')); ?>" alt="">-->
                                <!--    </div>-->
                                <!--</div>-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <!--<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pr-0 pt-3">-->
                                <div class="card-content">
                                    <h5 class="font-15">Employee</h5>
                                    <h2 class="mb-3 font-18"><?php echo e($userCount); ?></h2>
                                </div>
                                <!--</div>-->
                                <!--<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pl-0">-->
                                <!--    <div class="banner-img">-->
                                <!--        <img src="<?php echo e(asset('admin/assets/img/banner/4.png')); ?>" alt="">-->
                                <!--    </div>-->
                                <!--</div>-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <!--<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pr-0 pt-3">-->
                                <div class="card-content">
                                    <h5 class="font-15">clients</h5>
                                    <h2 class="mb-3 font-18"><?php echo e($clients); ?></h2>
                                </div>
                                <!--</div>-->
                                <!--<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pl-0">-->
                                <!--<div class="banner-img">-->
                                <!--    <img src="<?php echo e(asset('admin/assets/img/banner/3.png')); ?>" alt="">-->
                                <!--</div>-->
                                <!--</div>-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>

          

        
          
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Farhan ALi\Downloads\new portal\crm.w11stop.com\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>