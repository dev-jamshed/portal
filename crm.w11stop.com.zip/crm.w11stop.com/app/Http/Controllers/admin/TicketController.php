<?php

namespace App\Http\Controllers\admin;

use ZipArchive;
use App\Models\User;
use App\Models\client;
use App\Models\Ticket;
use App\Models\Project;
use App\Models\Attachment;
use App\Models\Department;
use App\Models\CommentFile;
use Illuminate\Http\Request;
use App\Models\SubDepartment;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;


class TicketController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }
    

    public function index()
    {
        $user = Auth::user();
        $tickets = Ticket::query();

        // Apply role-based conditions
        if ($user->hasRole('Sales')) {
            $tickets->where(function ($query) use ($user) {
                $query->where('user_id', $user->id)
                    ->where('status', 'Open')
                    ->orWhereIn('id', function ($subQuery) use ($user) {
                        $subQuery->select('ticket_id')
                            ->from('department_ticket')
                            ->where('department_id', $user->department_id);
                    });
            });
        } elseif ($user->hasRole('manager')) {
            $tickets->where(function ($query) use ($user) {
                $query->where('user_id', $user->id)
                    ->orWhereIn('id', function ($subQuery) use ($user) {
                        $subQuery->select('ticket_id')
                            ->from('department_ticket')
                            ->where('department_id', $user->department_id);
                    });
            });
        } elseif ($user->hasRole('super-admin')) {
            $tickets = Ticket::query();
        } elseif ($user->hasRole('Employee')) {
            $tickets->where(function ($query) use ($user) {
                $query->whereIn('id', function ($subQuery) use ($user) {
                    $subQuery->select('ticket_id')
                        ->from('sub_department_ticket')
                        ->where('sub_department_id', $user->sub_department_id);
                })->orWhereIn('id', function ($subQuery) use ($user) {
                    $subQuery->select('ticket_id')
                        ->from('department_ticket')
                        ->where('department_id', $user->department_id)
                        ->whereNotExists(function ($q) {
                            $q->select(DB::raw(1))
                                ->from('sub_department_ticket')
                                ->whereColumn('department_ticket.ticket_id', 'sub_department_ticket.ticket_id');
                        });
                })->orWhereIn('id', function ($subQuery) use ($user) {
                    $subQuery->select('ticket_id')
                        ->from('employee_ticket')
                        ->where('employee_id', $user->id);
                });
            });
        }

        // Debugging: Log the final SQL query
        Log::info('Tickets Query: ' . $tickets->toSql(), $tickets->getBindings());

        // Get tickets in descending order of creation date
        $tickets = $tickets->latest()->get();
        $users = User::all();
        $Departments = Department::all();

        return view('admin.tickets.index', compact('tickets','users','Departments'));
    }








    public function create()
    {
        $user = auth()->user();
        $departments = Department::all();
        $subDepartments = SubDepartment::all();
        $clients = Client::all();
        // return $clients;
        $projects = Project::all();
        // $employees = User::role('Employee')->get();
        $employees = User::get();

        // Common fields for all users
        $fields = [
            'subject',
            'description',
            'priority',
            'project_id',
            'department_id',
            'sub_department_id',
            'employee_id'
        ];

        $showProjectFields = false; // Initialize as false
        $projectFields = [];

        // Additional fields for Sales department users
        if ($user->department && $user->department->name === 'Sales') {
            $fields = array_diff($fields, ['project_id']); // Remove project_id field for Sales
            $showProjectFields = true;
            $projectFields = [
                'project_name',
                'project_deadline',
            ];
        }

        return view('admin.tickets.create', compact('departments', 'subDepartments', 'clients', 'projects', 'fields', 'showProjectFields', 'projectFields', 'employees', 'user'));
    }

    public function store(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'subject' => 'required|string|max:255',
            'description' => 'required|string',
            'priority' => 'required|in:low,medium,high',
            'project_name' => 'nullable|string|max:255',
            'project_deadline' => 'nullable|date',
            'project_id' => 'nullable|exists:projects,id',
            'department_ids' => 'nullable|array',
            'department_ids.*' => 'exists:departments,id',
            'sub_department_ids' => 'nullable|array',
            'sub_department_ids.*' => 'exists:sub_departments,id',
            'employee_ids' => 'nullable|array',
            'employee_ids.*' => 'exists:users,id',
            'price' => 'nullable|numeric',
            'attachments.*' => 'nullable|file|mimes:jpg,jpeg,png,pdf,doc,docx,xlsx',
        ]);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }
        $user = Auth::user();
        $client_id = $request->client_id;
        if (!$request->has('client_id') || $request->client_id == NULL) {
            if ($user->hasRole(['Sales', 'manager'])) {
                $request->client;
                $client = new client();
                $client->name = $request->c_name;
                $client->address = $request->c_address;
                $client->email = $request->c_email;
                $client->company_name = $request->c_company_name;
                $client->country = $request->c_country;
                $client->mobile_number = $request->c_mobile_number;
                $client->save();
                $client_id = $client->id;
            }
        }
        // Create the ticket
        $ticket = Ticket::create([
            'user_id' => Auth::user()->id,
            'subject' => $request->input('subject'),
            'description' => $request->input('description'),
            'priority' => $request->input('priority'),
            'project_name' => $request->input('project_name'),
            'project_deadline' => $request->input('project_deadline'),
            'project_id' => $request->input('project_id'),
            'client_id' => $client_id,
            'price' => $request->input('price'),
            'project_deadline' => $request->input('project_deadline'),
        ]);

        // Handle many-to-many relationships
        $ticket->departments()->sync($request->input('department_ids', []));
        $ticket->subDepartments()->sync($request->input('sub_department_ids', []));
        $ticket->employees()->sync($request->input('employee_ids', []));



        // Handle file uploads
        if ($request->hasFile('attachments')) {
            $files = $request->file('attachments');
            foreach ($files as $file) {
                if ($file->isValid()) {
                    // Define the destination path
                    $destinationPath = public_path('attachments');

                    // Generate a unique file name
                    $fileName = time() . '_' . $file->getClientOriginalName();

                    // Move the file to the destination path
                    $file->move($destinationPath, $fileName);

                    // Save file details in the database
                    $ticket->attachments()->create([
                        'ticket_id' => $ticket->id,
                        'file_path' => 'attachments/' . $fileName, // Relative path for database storage
                        'file_name' => $fileName,
                        'file_type' => $file->getClientOriginalExtension(),
                    ]);
                } else {
                    Log::error('Uploaded file is not valid.');
                }
            }
        }



        return redirect()->route('tickets.index')->with('success', 'Ticket created successfully.');
    }

    public function update(Request $request, Ticket $ticket)
    {
        // return $request;
        // Validate only the fields that are enabled in the form
        $validated = $request->validate([
            'department_ids' => 'nullable|array',
            'sub_department_ids' => 'nullable|array',
            'employee_ids' => 'nullable|array',
            'status' => 'required|string|in:open,in-progress,closed',
            'attachments.*' => 'nullable|file',
        ]);

        // Update departments
        if ($request->has('department_ids')) {
            $ticket->departments()->sync($validated['department_ids']);
        }

        // Update sub-departments
        if ($request->has('sub_department_ids')) {
            $ticket->subDepartments()->sync($validated['sub_department_ids']);
        }

        // Update employees
        if ($request->has('employee_ids')) {
            $ticket->employees()->sync($validated['employee_ids']);
        }

        // Update status
        $ticket->status = $validated['status'];

        // Save any attachments
        if ($request->hasFile('attachments')) {
            $files = $request->file('attachments');
            foreach ($files as $file) {
                if ($file->isValid()) {
                    // Define the destination path
                    $destinationPath = public_path('attachments');

                    // Generate a unique file name
                    $fileName = time() . '_' . $file->getClientOriginalName();

                    // Move the file to the destination path
                    $file->move($destinationPath, $fileName);

                    // Save file details in the database
                    $ticket->attachments()->create([
                        'ticket_id' => $ticket->id,
                        'file_path' => 'attachments/' . $fileName, // Relative path for database storage
                        'file_name' => $fileName,
                        'file_type' => $file->getClientOriginalExtension(),
                    ]);
                } else {
                    Log::error('Uploaded file is not valid.');
                }
            }
        }
        $ticket->save();

        if ($request->filled('comment')) {
            $comment = $ticket->comments()->create([
                'user_id' => auth()->id(),
                'comment' => $request->comment,
                'ticket_id' => $ticket->id,
            ]);

            // Handle comment attachments if any
            if ($request->hasFile('comment_attachments')) {
                foreach ($request->file('comment_attachments') as $file) {
                    $fileName = time() . '_' . $file->getClientOriginalName();
                    $destinationPath = 'attachments';
                    $file->move(public_path($destinationPath), $fileName);

                    $commentFile = CommentFile::create([
                        'comment_id' => $comment->id,
                        'file_path' => $destinationPath . '/' . $fileName,
                        'file_name' => $fileName,
                    ]);

                    // Log the created CommentFile object
                    Log::info('Comment File Created: ', $commentFile->toArray());
                }
            }
        } else if ($request->hasFile('comment_attachments')) {
            // If there is no comment but there are attachments
            foreach ($request->file('comment_attachments') as $file) {
                $fileName = time() . '_' . $file->getClientOriginalName();
                $destinationPath = 'attachments';
                $file->move(public_path($destinationPath), $fileName);

                // Create a dummy comment for the attachment
                $comment = $ticket->comments()->create([
                    'user_id' => auth()->id(),
                    'comment' => 'Attachment uploaded without a comment',
                    'ticket_id' => $ticket->id,
                ]);

                $commentFile = CommentFile::create([
                    'comment_id' => $comment->id,
                    'file_path' => $destinationPath . '/' . $fileName,
                    'file_name' => $fileName,
                ]);

                // Log the created CommentFile object
                Log::info('Comment File Created: ', $commentFile->toArray());
            }
        }


        // Save the ticket


        // Redirect to the tickets index page with a success message
        return redirect()->back()->with('success', 'Ticket updated successfully.');
    }


    public function edit($id)
    {

        $user = auth()->user();
        // return $user->roles->pluck('name'); 
        $ticket = Ticket::with(['comments' => function ($query) {
            $query->orderBy('created_at', 'desc'); // Fetch comments in descending order
        }])->findOrFail($id);

        $fields = [
            'subject',
            'description',
            'priority',
            'project_id',
            'department_id',
            'sub_department_id',
            'employee_id'
        ];

        $showClientDetails = false;
        $showPrice = false;

        if ($user->hasRole('Sales') && $ticket->user_id == $user->id) {
            $showClientDetails = true;
            $showPrice = true;
        } elseif ($user->hasRole('manager') || $user->hasRole('super-admin')) {
            $showClientDetails = true;
            $showPrice = true;
        }

        $departments = Department::all();
        $subDepartments = SubDepartment::all();
        $clients = Client::all();
        $projects = Project::all();
        $employees = User::all(); // Fetch 

        $assignedEmployeeIds = $ticket->employees->pluck('id')->toArray();

        return view('admin.tickets.edit', compact('ticket', 'departments', 'subDepartments', 'clients', 'projects', 'employees', 'showClientDetails', 'showPrice', 'user', 'assignedEmployeeIds', 'fields'));
    }

    public function downloadAll($ticketId)
    {
        // Get all attachments for the given ticket
        $attachments = Attachment::where('ticket_id', $ticketId)->get();

        // Create a new ZIP file
        $zip = new ZipArchive();
        $zipFileName = 'attachments_' . $ticketId . '.zip';
        $zipFilePath = public_path($zipFileName);

        if ($zip->open($zipFilePath, ZipArchive::CREATE) !== TRUE) {
            abort(500, 'Could not create ZIP file');
        }

        foreach ($attachments as $attachment) {
            $filePath = public_path('attachments/' . $attachment->file_name);
            if (file_exists($filePath)) {
                $zip->addFile($filePath, $attachment->original_name);
            }
        }

        $zip->close();

        // Return the ZIP file as a response
        return response()->download($zipFilePath)->deleteFileAfterSend(true);
    }


    public function download($id)
    {
        // Find the attachment by ID
        $attachment = Attachment::findOrFail($id);



        // Path to the file
        $filePath = public_path('attachments/' . $attachment->file_name);


        // Check if file exists
        if (!file_exists($filePath)) {
            abort(404, 'File not found');
        }

        // Return file as response
        return response()->download($filePath, $attachment->original_name);
    }
    public function comment_download($id)
    {
        // Find the attachment by ID
        $attachment = CommentFile::findOrFail($id);



        // Path to the file
        $filePath = public_path('attachments/' . $attachment->file_name);


        // Check if file exists
        if (!file_exists($filePath)) {
            abort(404, 'File not found');
        }

        // Return file as response
        return response()->download($filePath, $attachment->original_name);
    }


    public function search(Request $req)
    {
        $tempProducts = [];
        $products = null;
        if ($req->term != "") {
            $products = client::where('first_name', 'like', '%' . $req->term . '%')->get();
        }

        if ($products != null) {
            foreach ($products as $product) {
                $tempProducts[] = array('id' => $product->id, 'text' => $product->first_name);
            }
            return response()->json([
                'tags' => $tempProducts,
                'status' => true
            ]);
        }
    }
    public function fetchClient(Request $request)
    {
        $clientId = $request->clientId;

        // Fetch the client record from the database
        $client = Client::findOrFail($clientId);

        // Return the client record as JSON response
        return response()->json($client);
    }


    // public function store(Request $request)
    // {
    //     $validatedData = $request->validate([
    //         'subject' => 'required|string|max:255',
    //         'description' => 'required|string',
    //         'priority' => 'required|in:low,medium,high',
    //         'project_id' => 'nullable|exists:projects,id',
    //         'department_id' => 'nullable|exists:departments,id',
    //         'sub_department_id' => 'nullable|exists:sub_departments,id',
    //         'employee_id' => 'nullable|exists:users,id',
    //         'price' => 'nullable|numeric',
    //     ]);

    //     $ticket = new Ticket($validatedData);
    //     $ticket->client_id = auth()->user()->id; // Assuming the client is the logged-in user
    //     $ticket->status = 'open';
    //     $ticket->save();

    //     return redirect()->route('tickets.index')->with('success', 'Ticket created successfully.');
    // }

    // Other methods for show, edit, update, destroy, etc.
}
